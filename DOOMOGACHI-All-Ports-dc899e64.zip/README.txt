DOOMOGACHI console builds
Commit dc899e6414c3e8c5dbd3dd5cbcd4fc29c4e0a864 on main

Game Boy Advance
  Open doomogachi.gba in mGBA or use a GBA flash cart.

PlayStation (NTSC)
  Open doomogachi.cue from Standard or Talk. Keep the .bin beside it.
  Each edition also has a separately loadable PlayStation EXE.

PlayStation 2
  The 480i ISO is interlaced. The 480p ISO uses progressive output.
  Both are full game discs.

Dreamcast
  Open the self-booting doomogachi.cdi in Flycast or use compatible
  Dreamcast homebrew loading hardware.

BUILD_SOURCE.json records the source commit, artifact IDs and CI checks.
SHA256SUMS.txt lists the checksums of every game file.
